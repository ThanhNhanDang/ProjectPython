# drowsiness_detection
The system of detecting drowsiness for car drivers

Article link: http://ainoodle.tech/2019/09/05/cv-thu-lam-model-canh-bao-ngu-gat-cho-tai-xe-oto-bang-dlib-va-resnet/

#MìAI 
Fanpage: http://facebook.com/miaiblog<br>
Group trao đổi, chia sẻ: https://www.facebook.com/groups/miaigroup<br>
Website: http://ainoodle.tech<br>
Youtube: http://bit.ly/miaiyoutube<br>
