# MiAI_FaceRecog_2
Nhận diện khuôn mặt khá chuẩn xác bằng MTCNN và Facenet!

Article link: http://ainoodle.tech/2019/09/11/face-recog-2-0-nhan-dien-khuon-mat-trong-video-bang-mtcnn-va-facenet/

#MìAI 
Fanpage: http://facebook.com/miaiblog<br>
Group trao đổi, chia sẻ: https://www.facebook.com/groups/miaigroup<br>
Website: http://ainoodle.tech<br>
Youtube: http://bit.ly/miaiyoutube<br>
